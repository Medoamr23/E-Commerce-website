<?php $cur = basename($_SERVER['PHP_SELF']); ?>
<h1>Admin dashboard</h1>
<div class="admin-nav">
<?php foreach (['index.php'=>'Overview','products.php'=>'Products','orders.php'=>'Orders','users.php'=>'Users','comments.php'=>'Comments','categories.php'=>'Categories'] as $f=>$l): ?>
  <a href="<?= $f ?>" class="<?= $cur === $f ? 'on' : '' ?>"><?= $l ?></a>
<?php endforeach; ?>
</div>
