<?php define('IN_ADMIN', true); require_once '../config.php'; require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $id = (int)$_POST['id'];
    if ($id === (int)user()['id']) flash('You cannot change your own account here.');
    elseif ($_POST['action'] === 'toggle_admin') { $pdo->prepare('UPDATE users SET is_admin = 1 - is_admin WHERE id=?')->execute([$id]); flash('Role updated.'); }
    elseif ($_POST['action'] === 'delete') { $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]); flash('User deleted.'); }
    header('Location: users.php'); exit;
}
$users = $pdo->query('SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.user_id=u.id) AS orders FROM users u ORDER BY u.created_at DESC')->fetchAll();
$pageTitle = 'Admin · Users'; require '../header.php'; require '_nav.php'; ?>
<table class="table">
  <tr><th>Name</th><th>Email</th><th>Role</th><th>Orders</th><th>Joined</th><th></th></tr>
  <?php foreach ($users as $u): ?>
  <tr><td><?= e($u['name']) ?></td><td><?= e($u['email']) ?></td><td><?= $u['is_admin'] ? '<span class="badge">admin</span>' : 'customer' ?></td>
    <td><?= $u['orders'] ?></td><td><?= e($u['created_at']) ?></td>
    <td><?php if ($u['id'] != user()['id']): ?>
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $u['id'] ?>"><input type="hidden" name="action" value="toggle_admin">
        <button class="btn small"><?= $u['is_admin'] ? 'Remove admin' : 'Make admin' ?></button></form>
      <form method="post" class="inline" onsubmit="return confirm('Delete this user and their orders?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $u['id'] ?>"><input type="hidden" name="action" value="delete">
        <button class="btn danger small">Delete</button></form>
    <?php else: ?>(you)<?php endif; ?></td></tr>
  <?php endforeach; ?>
</table>
<?php require '../footer.php'; ?>
